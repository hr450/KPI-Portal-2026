# Rankviz KPI Dashboard – Vercel Deploy

Frontend = Vercel (static, `public/`). Database + logic = Google Sheet + Apps Script (pehle jaisa).
Login = Google Sign-In (sirf @rankviz.com). Server har request par token verify karta hai.

## 1) Google OAuth Client ID (ek baar)
1. console.cloud.google.com > project banayein > APIs & Services > OAuth consent screen (Internal) > Create.
2. Credentials > Create credentials > OAuth client ID > **Web application**.
3. Authorized JavaScript origins: `http://localhost:3000` aur baad me apna Vercel URL (`https://xxxx.vercel.app`, custom domain ho to wo bhi).
4. Client ID copy karein.

## 2) Apps Script (hr@rankviz.com se)
1. Database sheet > Extensions > Apps Script.
2. Nayi file `Api.gs` banayein, `apps-script/Api.gs` paste karein. `BackupRestore.gs` pehle se hai to wahi rakhein.
3. Project Settings > Script properties > `GOOGLE_CLIENT_ID` = step 1 wali Client ID.
4. Project Settings > manifest file show karein > `appsscript.json` replace (Execute as: Me, Access: **Anyone**).
5. **Zaroori:** Code.gs / Admin.gs / baqi sab files me search karein `Session.getActiveUser().getEmail()` aur har jagah `userEmail_()` likh dein
   (warna anonymous access me email khali aayegi aur sab "no access" dikhayega).
6. Deploy > New deployment > Web app > Execute as: Me, Access: Anyone > Deploy. URL (`…/exec`) copy karein.
7. Update karte waqt: Deploy > Manage deployments > pencil > New version.

## 3) Frontend config
`public/config.js` me `API_URL` aur `GOOGLE_CLIENT_ID` paste karein.

## 4) Vercel deploy
**GitHub se (recommended):** is folder ko GitHub repo me push karein > vercel.com > Add New Project > repo import >
Framework: Other, Build Command khali, Output Directory `public` (vercel.json me already hai) > Deploy.

**CLI se:**
```
npm i -g vercel
vercel          # pehli baar (preview)
vercel --prod   # live
```
Deploy ke baad Vercel URL ko Google OAuth ke "Authorized JavaScript origins" me add karna na bhulein.

## Local test
```
npx serve public -l 3000
```

## Troubleshooting
- "Server se connect nahi ho saka": API_URL galat ya deployment "Anyone" nahi hai.
- Sign-in button par `origin_mismatch`: Vercel URL OAuth origins me add nahi.
- "This account is not allowed": GOOGLE_CLIENT_ID property ya domain (hd) match nahi.
- Data nahi dikhta / no access: step 2.5 (userEmail_) reh gaya.
