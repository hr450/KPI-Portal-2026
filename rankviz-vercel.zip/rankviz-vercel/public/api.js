/* Rankviz KPI – google.script.run replacement (Vercel -> Apps Script API)
 * Google Sign-In (ID token) -> fetch(Apps Script) -> server token verify karta hai. */
(function () {
  const C = window.RANKVIZ || {};
  const KEY = 'rv_id_token';
  let waiters = [], gsiReady = null;

  function jwt(t) { try { return JSON.parse(atob(t.split('.')[1].replace(/-/g, '+').replace(/_/g, '/'))); } catch (e) { return null; } }
  function stored() {
    const t = sessionStorage.getItem(KEY), p = t && jwt(t);
    return p && p.exp * 1000 > Date.now() + 60000 ? t : null;
  }

  /* ---------- login overlay ---------- */
  function overlay(msg) {
    let o = document.getElementById('rv-login');
    if (!o) {
      o = document.createElement('div'); o.id = 'rv-login';
      o.style.cssText = 'position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#071a3d,#0A1F44);font-family:"DM Sans",Arial,sans-serif';
      o.innerHTML = '<div style="background:#fff;border-radius:18px;padding:34px 38px;text-align:center;max-width:360px;box-shadow:0 20px 60px rgba(0,0,0,.4)">' +
        '<h2 style="margin:0 0 6px;color:#0A1F44;font-family:Manrope,sans-serif">Rankviz KPI Dashboard</h2>' +
        '<p id="rv-msg" style="margin:0 0 20px;color:#6B7A99;font-size:14px"></p><div id="rv-btn" style="display:flex;justify-content:center"></div></div>';
      document.body.appendChild(o);
    }
    o.style.display = 'flex';
    o.querySelector('#rv-msg').textContent = msg || ('Apne @' + C.ALLOWED_DOMAIN + ' Google account se sign in karein');
    return o;
  }
  function hide() { const o = document.getElementById('rv-login'); if (o) o.style.display = 'none'; }

  function loadGsi() {
    if (gsiReady) return gsiReady;
    gsiReady = new Promise((res, rej) => {
      const s = document.createElement('script');
      s.src = 'https://accounts.google.com/gsi/client'; s.async = true;
      s.onload = res; s.onerror = () => rej(new Error('Google Sign-In load nahi hua. Internet check karein.'));
      document.head.appendChild(s);
    });
    return gsiReady;
  }

  function onCred(resp) {
    const p = jwt(resp.credential);
    if (!p || (C.ALLOWED_DOMAIN && p.hd !== C.ALLOWED_DOMAIN)) { overlay('Sirf @' + C.ALLOWED_DOMAIN + ' account allowed hai.'); renderBtn(); return; }
    sessionStorage.setItem(KEY, resp.credential);
    hide();
    const w = waiters; waiters = []; w.forEach(f => f(resp.credential));
  }
  function renderBtn() {
    const b = document.getElementById('rv-btn'); b.innerHTML = '';
    google.accounts.id.renderButton(b, { theme: 'filled_blue', size: 'large', text: 'signin_with', shape: 'pill' });
  }

  function getToken() {
    const t = stored(); if (t) return Promise.resolve(t);
    return new Promise((resolve, reject) => {
      waiters.push(resolve);
      if (waiters.length > 1) return;
      overlay();
      loadGsi().then(() => {
        google.accounts.id.initialize({ client_id: C.GOOGLE_CLIENT_ID, callback: onCred, hd: C.ALLOWED_DOMAIN, auto_select: true, cancel_on_tap_outside: false });
        renderBtn();
        google.accounts.id.prompt();
      }).catch(e => { waiters = []; overlay(e.message); reject(e); });
    });
  }

  /* ---------- API call ---------- */
  async function call(fn, args, retry) {
    const token = await getToken();
    let r;
    try {
      r = await fetch(C.API_URL, { method: 'POST', redirect: 'follow',
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },   // preflight se bachne ke liye
        body: JSON.stringify({ fn: fn, args: args, token: token }) });
    } catch (e) { throw new Error('Server se connect nahi ho saka. Internet / API_URL check karein.'); }
    let d; try { d = await r.json(); } catch (e) { throw new Error('Server ka jawab samajh nahi aaya (Apps Script deployment check karein).'); }
    if (!d.ok) {
      if (d.code === 'AUTH' && !retry) { sessionStorage.removeItem(KEY); return call(fn, args, true); }
      throw new Error(d.error || 'Unknown error');
    }
    return d.result;
  }

  /* ---------- google.script.run compatible proxy ---------- */
  const mk = (ok, fail) => new Proxy({}, { get: (_, k) =>
    k === 'withSuccessHandler' ? g => mk(g, fail) :
    k === 'withFailureHandler' ? g => mk(ok, g) :
    (...a) => { call(k, a).then(v => ok && ok(v)).catch(e => fail ? fail(e) : alert(e.message)); } });
  window.google = { script: { run: mk() } };

  window.rvSignOut = () => { sessionStorage.removeItem(KEY); if (window.google && google.accounts) google.accounts.id.disableAutoSelect(); location.reload(); };
})();
