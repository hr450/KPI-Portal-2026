/* ====== SIRF YEHI FILE EDIT KARNI HAI ====== */
window.RANKVIZ = {
  // Apps Script > Deploy > Web app wala URL (…/exec par khatam hota hai)
  API_URL: "PASTE_APPS_SCRIPT_WEB_APP_URL_HERE",
  // Google Cloud Console > Credentials > OAuth client ID (Web application)
  GOOGLE_CLIENT_ID: "PASTE_YOUR_CLIENT_ID.apps.googleusercontent.com",
  // Sirf is domain ke accounts login kar sakte hain
  ALLOWED_DOMAIN: "rankviz.com"
};
