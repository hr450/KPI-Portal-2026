/** Rankviz KPI – Vercel frontend ke liye JSON API.
 *  Apps Script project me NAYI file banayein: Api.gs  (baqi .gs files wese hi rahengi)
 *
 *  Pehle: Project Settings > Script properties > Add:
 *     GOOGLE_CLIENT_ID = <aapka OAuth client id>
 */
const API_DOMAIN_ = 'rankviz.com';
const API_FNS_ = ['getBoot', 'saveScores', 'adminData', 'exportBackup', 'restoreBackup',
                  'deleteEmployee', 'kpiAdd', 'saveAccess', 'saveEmployee', 'setActive', 'subAdd', 'subWeight'];
var API_USER_ = null;   // doPost me verified email yahan set hoti hai

/** Code.gs / Admin.gs me jahan bhi Session.getActiveUser().getEmail() ho, usay userEmail_() se replace karein. */
function userEmail_() {
  return String(API_USER_ || Session.getActiveUser().getEmail() || '').toLowerCase();
}

function doPost(e) {
  try {
    const req = JSON.parse(e.postData.contents);
    API_USER_ = verifyToken_(req.token);
    if (API_FNS_.indexOf(req.fn) < 0) throw new Error('Unknown function: ' + req.fn);
    const result = globalThis[req.fn].apply(null, req.args || []);
    return json_({ ok: true, result: result === undefined ? null : result });
  } catch (err) {
    return json_({ ok: false, code: err.code || '', error: String(err.message || err) });
  }
}

function json_(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }
function authErr_(m) { const e = new Error(m); e.code = 'AUTH'; return e; }

function verifyToken_(token) {
  if (!token) throw authErr_('Please sign in.');
  const cache = CacheService.getScriptCache();
  const key = 'tok_' + Utilities.base64EncodeWebSafe(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, token));
  const hit = cache.get(key); if (hit) return hit;

  const cid = PropertiesService.getScriptProperties().getProperty('GOOGLE_CLIENT_ID');
  if (!cid) throw new Error('GOOGLE_CLIENT_ID script property set nahi hai.');
  const r = UrlFetchApp.fetch('https://oauth2.googleapis.com/tokeninfo?id_token=' + encodeURIComponent(token), { muteHttpExceptions: true });
  if (r.getResponseCode() !== 200) throw authErr_('Session expired. Please sign in again.');
  const t = JSON.parse(r.getContentText());
  const ttl = Number(t.exp) - Math.floor(Date.now() / 1000);
  if (t.aud !== cid || String(t.email_verified) !== 'true' || t.hd !== API_DOMAIN_ || ttl <= 0)
    throw authErr_('This account is not allowed.');
  const email = String(t.email).toLowerCase();
  cache.put(key, email, Math.min(ttl, 3000));
  return email;
}
