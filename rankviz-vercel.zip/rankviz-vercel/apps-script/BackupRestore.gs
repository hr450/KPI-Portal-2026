/** DOWNLOAD / RESTORE of the whole KPI database (HR only, checked on the server).
 *  Add this as a new file (e.g. BackupRestore.gs) in the Apps Script project. */
const BACKUP_TABS = ['Employees', 'Access', 'KPIs', 'SubMetrics', 'Scores'];
const MONTH_COLS_ = ['Month', 'Join Month', 'Start Month', 'End Month'];   // kept as plain text "2026-07"

function exportBackup() {
  hr_();
  const tz = Session.getScriptTimeZone(), out = { app: 'rankviz-kpi', version: 1, exported: Utilities.formatDate(new Date(), tz, 'yyyy-MM-dd HH:mm'), tabs: {} };
  BACKUP_TABS.forEach(function (n) {
    const v = sh_(n).getDataRange().getValues(), head = v[0].map(function (h) { return String(h); });
    out.tabs[n] = { header: head, rows: v.slice(1).filter(function (r) { return r.some(function (c) { return c !== ''; }); }).map(function (r) {
      return r.map(function (c, i) {
        if (!(c instanceof Date)) return c;
        return Utilities.formatDate(c, tz, MONTH_COLS_.indexOf(head[i]) >= 0 ? 'yyyy-MM' : head[i] === 'Expires' ? 'yyyy-MM-dd' : 'yyyy-MM-dd HH:mm');
      });
    }) };
  });
  return JSON.stringify(out);
}

// REPLACES the database with the file's contents. Checks everything first; a Drive copy of the current data is made before any change.
function restoreBackup(text) {
  hr_();
  let d; try { d = JSON.parse(text); } catch (e) { throw new Error('This is not a valid backup file.'); }
  if (!d || d.app !== 'rankviz-kpi' || !d.tabs) throw new Error('This is not a Rankviz KPI backup file.');
  BACKUP_TABS.forEach(function (n) {
    const s = sh_(n), t = d.tabs[n], cur = s.getRange(1, 1, 1, s.getLastColumn()).getValues()[0].map(function (h) { return String(h); });
    if (!t || JSON.stringify(t.header) !== JSON.stringify(cur)) throw new Error('Tab "' + n + '" does not match the current database layout. Nothing was changed.');
  });
  if (!d.tabs.Employees.rows.length) throw new Error('The backup has no employees. Nothing was changed.');
  if (typeof backupNow === 'function') backupNow();                       // safety copy of the CURRENT data first
  const lock = LockService.getScriptLock(); lock.waitLock(30000);
  try {
    BACKUP_TABS.forEach(function (n) {
      const s = sh_(n), t = d.tabs[n], cols = t.header.length, need = t.rows.length + 1;
      if (s.getLastRow() > 1) s.getRange(2, 1, s.getLastRow() - 1, cols).clearContent();
      if (s.getMaxRows() < need) s.insertRowsAfter(s.getMaxRows(), need - s.getMaxRows());
      t.header.forEach(function (h, i) { if (MONTH_COLS_.indexOf(h) >= 0) s.getRange(2, i + 1, s.getMaxRows() - 1, 1).setNumberFormat('@'); });
      if (t.rows.length) s.getRange(2, 1, t.rows.length, cols).setValues(t.rows);
    });
  } finally { lock.releaseLock(); }
  bust_();
  return 'Restored from backup of ' + d.exported + ': ' + BACKUP_TABS.map(function (n) { return d.tabs[n].rows.length + ' ' + n; }).join(', ') + '.';
}
